export default {
  API : "https://stellarot.herokuapp.com/v1/"
};